// Sets the name of this project
rootProject.name = "Lab1"

